const names = ["Rohan", "Ankush", "Gitesh"];
const nameLengths = names.map(name=> name.length);
console.log(nameLengths);