const AssaultRifles = ["Vandal","Phantom"];
const Snipers = ["Operator","Marshal"];
const allGuns = [...AssaultRifles, ...Snipers];
console.log(allGuns);