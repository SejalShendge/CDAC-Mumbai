const book = {
    title : "JavaScript : The Good Parts",
    author : "Douglas Crackford",
    yearPublished : 2008,

    displayDetails(){
        console.log(`Title : ${this.title}, Author : ${this.author}, Year : ${this.yearPublished}`);
    }   
};
book.displayDetails();

