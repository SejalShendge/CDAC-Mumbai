const TAX_RATE = 0.07;
let cart = [];
let totalPrice = 0;

function addItem(item, price) {
    cart.push({item, price});
    totalPrice += price;
}

function calculateTotal() {
    return totalPrice + totalPrice * TAX_RATE;
}

addItem('Bat', 2000);
addItem('Bowl', 250);
console.log(`Total (including tax): ₹${calculateTotal()}`);