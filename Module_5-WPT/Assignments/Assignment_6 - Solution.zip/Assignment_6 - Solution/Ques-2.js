function areaRectangle(length, width){
    return length * width;
}
const areaRectangleArrow = (length, width) => length * width;

console.log(areaRectangle(17, 15));
console.log(areaRectangleArrow(17, 15));