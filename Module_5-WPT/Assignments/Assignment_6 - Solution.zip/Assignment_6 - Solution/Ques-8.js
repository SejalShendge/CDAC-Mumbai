const carItems = [{ item : "Kuronami Vandal", price : 2600}, { item : "Champions Phantom", price : 2500}, { item : "Oni Bundel", price : 6150}];
const total = carItems.reduce((sum, item) => sum + item.price, 0);
console.log(`Total Price : ₹${total}`);