function executeAfterDelay (callback, delay){
    setTimeout(callback, delay);
}
executeAfterDelay(() => console.log("Executed After Delay ~ Rohan "), 2000);