const car = { make : "Mahindra", model : "Thar ROXX", year : 2024};
const  {make, model, year} = car;
console.log(make, model, year);