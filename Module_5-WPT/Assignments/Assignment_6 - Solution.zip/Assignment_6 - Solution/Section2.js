const MAX_EXPENSE_LIMIT = 50000;
let expenses = [];
let totalExpense = 0;

function addExpense(description, amount, date = new Date().toLocaleDateString()) {
    const expense = { description, amount, date };
    expenses = [...expenses, expense];
    totalExpense += amount;
    showMessage(() => console.log("Expense added successfully!"));
}

const displayExpenses = () => {
    console.log("Expenses List:");
    expenses.forEach(({ description, amount, date }) => {
        console.log(`Description: ${description}, Amount: ₹${amount}, Date: ${date}`);
    });
};

const calculateTotalExpenses = () => expenses.reduce((total, expense) => total + expense.amount, 0);

function displayExpenseDescriptions() {
    const descriptions = expenses.map(({ description }) => description);
    console.log("Expense Descriptions:", descriptions);
}

function displayLargeExpenses(threshold = 2000) {
    const largeExpenses = expenses.filter(({ amount }) => amount > threshold);
    console.log("Expenses above ₹" + threshold + ":");
    largeExpenses.forEach(({ description, amount, date }) => {
        console.log(`Description: ${description}, Amount: ₹${amount}, Date: ${date}`);
    });
}

function addMultipleExpenses(...newExpenses) {
    newExpenses.forEach(({ description, amount, date }) => addExpense(description, amount, date));
}

function showMessage(callback) {
    callback();
}

function fetchInitialExpenses() {
    return new Promise((resolve) => {
        const initialExpenses = [
            { description: "Groceries", amount: 1500, date: "2024-11-01" },
            { description: "Electricity Bill", amount: 3000, date: "2024-11-02" },
        ];
        setTimeout(() => resolve(initialExpenses), 1000);
    });
}

function createExpenseTracker() {
    let total = 0;
    return function (amount) {
        total += amount;
        return total;
    };
}
const trackTotal = createExpenseTracker();

async function initializeExpenses() {
    try {
        const initialExpenses = await fetchInitialExpenses();
        initialExpenses.forEach(({ description, amount, date }) => {
            addExpense(description, amount, date);
            trackTotal(amount);
        });
        console.log("Initial expenses loaded successfully.");
        displayExpenses();
    } catch (error) {
        console.error("Error fetching initial expenses:", error);
    }
}

initializeExpenses();

addExpense("Lunch", 150);
displayExpenseDescriptions();
displayLargeExpenses(2000);
console.log("Total Expenses:", `₹${calculateTotalExpenses()}`);
addMultipleExpenses(
    { description: "Petrol", amount: 1000, date: "2024-11-02" },
    { description: "Internet", amount: 800, date: "2024-11-03" }
);
console.log("Total after multiple additions:", `₹${calculateTotalExpenses()}`);
