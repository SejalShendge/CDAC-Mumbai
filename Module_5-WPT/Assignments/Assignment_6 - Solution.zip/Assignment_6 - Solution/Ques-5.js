const numbers = [15,7,17,9,2,];
const[first, second] = numbers;
console.log(first, second);